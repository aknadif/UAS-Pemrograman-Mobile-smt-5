<?php    
    include 'config.php';
    $conn = mysqli_connect(SERVER, UID, PASSWORD, DB_NAME);
