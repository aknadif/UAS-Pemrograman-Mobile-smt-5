<?php 
require_once "connection.php";

if($conn){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $insert = "INSERT INTO login(username, password, email) VALUES('$username', '$password', '$email') ";


    if($username != "" && $password != "" & $email !=""){
        $result = mysqli_query($conn, $insert);
        $response = array();

        if($result){
            array_push($response, array(
                'status' => 'OK'
            ));
        } else{
            array_push($response, array(
                'status' => 'FAILED'
            ));
        }
    } else{
        array_push($response, array(
            'status' => 'FAILED'
        ));
    }
} else {
        array_push($response, array(
            'status' => 'FAILED'
    ));
}
echo json_encode(array("server_response" => $response));
mysqli_close($conn);